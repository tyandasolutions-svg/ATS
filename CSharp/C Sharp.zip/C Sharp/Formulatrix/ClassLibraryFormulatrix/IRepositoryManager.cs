﻿using System;

namespace ClassLibraryFormulatrix

{
    /**
     * interface for storage management class
     */

    public interface IRepositoryManager

    {

        /**
         * initialize for creating storage
         * this is mandatory step before doing any other actions
         */
        void Initialize();

        /**
         * register content storage
         */
        void Register(string itemName, string itemContent, int itemType);

        /**
         * get content value by item key
         */
        string Retrieve(string itemName);

        /**
         * get content by item key
         */
        int GetType(string itemName);

        /**
         * remove content value from storage
         */
        void Deregister(string itemName);

    }

}