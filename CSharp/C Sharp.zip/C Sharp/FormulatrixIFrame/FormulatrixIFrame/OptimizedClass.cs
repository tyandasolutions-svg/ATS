﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace Formulatrix.Intern.GrabTheFrame
{
    // use same contract interfaces like in assessment
    public interface NewIFrameCallback
    {
        void FrameReceived(IntPtr pFrame, int pixelWidth, int pixelHeight);
    }
    public interface NewIValueReporter
    {
        void Report(double value);
    }
    public class OptimizedFrameCalculateAndStream : IDisposable
    {
        private readonly NewIValueReporter _reporter;
        private readonly ConcurrentQueue<byte[]> _frameQueue = new ConcurrentQueue<byte[]>();
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private bool _isStreaming = false;

        public OptimizedFrameCalculateAndStream(NewFrameGrabber fg, NewIValueReporter vr)
        {
            _reporter = vr;
            // Subscribe ke event dari grabber
            fg.OnFrameUpdated += HandleFrameUpdated;
        }

        private void HandleFrameUpdated(byte[] frameData)
        {
            // Use Deep Copy so that data is not overwritten by the native buffer.
            byte[] persistentBuffer = new byte[frameData.Length];
            Buffer.BlockCopy(frameData, 0, persistentBuffer, 0, frameData.Length);

            _frameQueue.Enqueue(persistentBuffer);
        }

        public void StartStreaming()
        {
            if (_isStreaming) return;
            _isStreaming = true;

            // Using Long-running Tasks instead of Timers
            // real-time process
            Task.Factory.StartNew(ProcessFrames, _cts.Token,
                TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        private void ProcessFrames()
        {
            while (!_cts.Token.IsCancellationRequested)
            {
                if (_frameQueue.TryDequeue(out byte[] rawData))
                {
                    double average = CalculateAverage(rawData);
                    _reporter.Report(average);
                }
                else
                {
                    // rest
                    Thread.Sleep(1);
                }
            }
        }

        private double CalculateAverage(byte[] data)
        {
            if (data == null || data.Length == 0) return 0;

            long totalSum = 0; // Prevent Integer Overflow
            for (int i = 0; i < data.Length; i++)
            {
                totalSum += data[i];
            }

            return (double)totalSum / data.Length;
        }

        public void Dispose()
        {
            _cts.Cancel();
            _cts.Dispose();
        }
    }

    public class NewFrameGrabber : NewIFrameCallback
    {
        public delegate void FrameUpdateHandler(byte[] frameData);
        public event FrameUpdateHandler OnFrameUpdated;
        private byte[] _managedBuffer;

        public void FrameReceived(IntPtr pFrame, int width, int height)
        {
            int size = width * height;

            // re-use buffer to minimize memory allocation (Garbage Collection)
            if (_managedBuffer == null || _managedBuffer.Length != size)
            {
                _managedBuffer = new byte[size];
            }

            // copy from native pointer to managed memory
            System.Runtime.InteropServices.Marshal.Copy(pFrame, _managedBuffer, 0, size);

            // send data to subscriber
            OnFrameUpdated?.Invoke(_managedBuffer);
        }
    }
}
