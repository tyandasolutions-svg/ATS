﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingCompetensiTest
{
    public class DivisibilityGenerator
    {
        private List<DivisibilityRule> rules;

        public DivisibilityGenerator()
        {
            rules = new List<DivisibilityRule>();
        }

        /**
         * Method to add division rule,
         * rule will be executed respectively
         */
        public void AddRule(int divisor, string message)
        {
            rules.Add(new DivisibilityRule(divisor, message));
        }

        /**
         * Method to print output from rule set
         * 
         */
        public void GenerateOutput(int n)
        {
            string output = "";

            for (int i = 1; i <= n; i++)
            {
                string str = "";
                foreach (var rule in rules)
                {
                    if (i % rule.Divisor == 0)
                    {
                        str = rule.Message;
                        break;
                    }
                    str = i.ToString(); 
                }
                output = GetConcatString(output, str);
            }

            Console.WriteLine(output);
        }

        /**
         * Method for custom method concenation string
         * 
         */
        static string GetConcatString(string str, string newValue)
        {
            if (string.IsNullOrWhiteSpace(str))
            {
                return newValue;
            }
            else
            {
                return str = str + ", " + newValue;
            }
        }
    }

}
