﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CodingCompetensiTest
{
    internal class Program
    {
        // reff : 
        //writing fizzBuzz - Stack Overflow
        //a clean fizzBuzz solution - andy crouch
        static void Main(string[] args)
        {
            Console.Write("Enter a number n: ");
            int n = int.Parse(Console.ReadLine());

            //for running please unRemark 

            // call assessment no. 1
            AssessmentNo1(n);

            // call assessment no. 2
            //AssessmentNo2(n);

            // call assessment no. 3
            //AssessmentNo3(n);

            // call assessment no. 4
            //AssessmentNo4(n);
        }

        static string GetConcatString(string str, string newValue)
        {
            if (string.IsNullOrWhiteSpace(str))
            {
                return newValue;
            }
            else
            {
                return str = str + ", " + newValue;
            }
        }

        static void AssessmentNo4(int n)
        {
            // create a new DivisibilityGenerator
            DivisibilityGenerator generator = new DivisibilityGenerator();

            // configure rules using the API
            generator.AddRule(9, "huzz");
            generator.AddRule(3, "foo");
            generator.AddRule(4, "baz");
            generator.AddRule(5, "bar");
            generator.AddRule(7, "jazz");

            // generate output
            generator.GenerateOutput(n);
        }

        static void AssessmentNo3(int n)
        {
            String printStr = "";

            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    printStr = GetConcatString(printStr, "foobar");
                }
                else if (i % 9 == 0)
                {
                    printStr = GetConcatString(printStr, "huzz");
                }
                else if (i % 3 == 0)
                {
                    printStr = GetConcatString(printStr, "foo");
                }
                else if (i % 4 == 0)
                {
                    printStr = GetConcatString(printStr, "baz");
                }
                else if (i % 5 == 0)
                {
                    printStr = GetConcatString(printStr, "bar");
                }
                else if (i % 7 == 0)
                {
                    printStr = GetConcatString(printStr, "jazz");
                }
                else
                {
                    printStr = GetConcatString(printStr, Convert.ToString(i));
                }
            }

            Console.WriteLine(printStr);
        }

        static void AssessmentNo2(int n)
        {
            string printStr = "";
            string currStr = "";
            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    currStr += "foobar";
                }
                else if (i % 3 == 0)
                {
                    currStr += "foo";
                }
                else if (i % 5 == 0)
                {
                    currStr += "bar";
                }
                else
                {
                    if (i % 7 == 0)
                    {
                        currStr += "jazz";
                    }
                    else
                    {
                        currStr = i.ToString();
                    }
                }

                // check if not number
                if (!Regex.Match(currStr, @"[0-9]*").Success)
                {
                    currStr += "jazz";
                }

                printStr = GetConcatString(printStr, currStr);
                currStr = "";
            }

            Console.WriteLine(printStr);
        }

        static void AssessmentNo1(int n)
        {
            String printStr = "";

            for (int i = 1; i <= n; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    printStr = GetConcatString(printStr, "foobar");
                }
                else if (i % 3 == 0)
                {
                    printStr = GetConcatString(printStr, "foo");
                }
                else if (i % 5 == 0)
                {
                    printStr = GetConcatString(printStr, "bar");
                }
                else
                {
                    printStr = GetConcatString(printStr, Convert.ToString(i));
                }
            }

            Console.WriteLine(printStr);
        }
    }
}
