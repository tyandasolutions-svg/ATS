﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace ClassLibraryFormulatrix
{
    // setter getter item object
    public class RepositoryItem
    {
        public string Content { get; set; }
        public int Type { get; set; } // type object: 1 for json, 2 for xml
    }

    public class FormulatrixRepositoryManager : IRepositoryManager
    {
        // use ConcurrentDictionary for multithreading like in APIs
        private ConcurrentDictionary<string, RepositoryItem> _storage;

        // flag to indicate empty storage or not
        private bool _isInitialized = false;

        /**
         * initialize for creating storage
         */
        public void Initialize()
        {
            // don't initialize more than once
            if (_isInitialized)
                throw new InvalidOperationException("Repository already initialized.");

            // create stogare object
            _storage = new ConcurrentDictionary<string, RepositoryItem>();

            // update flag
            _isInitialized = true;
        }

        /**
         * register / insert content of storage
         */
        public void Register(string itemName, string itemContent, int itemType)
        {
            // check storage creation
            CheckInitialization();

            // validate content value
            if (!IsValidContent(itemContent, itemType))
            {
                throw new ArgumentException("Invalid content format for the specified type.");
            }

            // avoid duplicate key
            if (_storage.ContainsKey(itemName))
            {
                throw new InvalidOperationException($"Item with name '{itemName}' is already registered.");
            }

            // object insert
            var newItem = new RepositoryItem
            {
                Content = itemContent,
                Type = itemType
            };

            // add object to storage
            if (!_storage.TryAdd(itemName, newItem))
            {
                throw new Exception("Failed to register item.");
            }
        }

        /**
         * get content value by item key
         */
        public string Retrieve(string itemName)
        {
            // check storage creation
            CheckInitialization();

            // get value in storage
            if (_storage.TryGetValue(itemName, out var item))
            {
                return item.Content;
            }

            // throw error when not found
            throw new KeyNotFoundException("Item not found.");
        }

        /**
         * get type (json, xml) from item name
         */
        public int GetType(string itemName)
        {
            // check storage creation
            CheckInitialization();

            // get type in storage
            if (_storage.TryGetValue(itemName, out var item))
            {
                return item.Type;
            }

            // throw error when not found
            throw new KeyNotFoundException("Item not found.");
        }

        /**
         * remove content value from storage
         */
        public void Deregister(string itemName)
        {
            // check object creation
            CheckInitialization();

            // remove value in storage, throw error when not found
            if (!_storage.TryRemove(itemName, out _))
            {
                throw new KeyNotFoundException("Item not found or already removed.");
            }
        }

        /**
         * validate format content value in storage
         */
        private bool IsValidContent(string content, int type)
        {
            if (string.IsNullOrEmpty(content)) return false;

            if (type == 1) // json validation
            {
                return content.Trim().StartsWith("{") || content.Trim().StartsWith("[");
            }
            else if (type == 2) // xml validation
            {
                return content.Trim().StartsWith("<");
            }
            return false;
        }

        /**
         * validate storage creation
         */
        private void CheckInitialization()
        {
            // check flag
            if (!_isInitialized)
                throw new InvalidOperationException("Manager must be initialized before use.");
        }
    }
}
