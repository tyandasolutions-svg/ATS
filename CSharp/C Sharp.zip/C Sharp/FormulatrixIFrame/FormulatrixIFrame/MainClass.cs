﻿using System;

using System.Collections.Generic;

using System.Runtime.InteropServices;

using System.Timers;

// this is the exact class from assesment pdf
namespace Formulatrix.Intern.GrabTheFrame
{
    public interface IFrameCallback
    {
        void FrameReceived(IntPtr pFrame, int pixelWidth, int pixelHeight);
    }
    public interface IValueReporter
    {
        void Report(double value);
    }
    public class FrameCalculateAndStream
    {
        private IValueReporter _reporter;
        private Queue<Frame> _receivedFrames = new Queue<Frame>();
        private Timer _timer;
        public FrameCalculateAndStream(FrameGrabber fg, IValueReporter vr)
        {
            fg.OnFrameUpdated += HandleFrameUpdated;
            _timer = new Timer(1000 / 30);
            _timer.Elapsed += OnTimerElapsed;
            _reporter = vr;
        }
        private void HandleFrameUpdated(Frame frame)
        {
            _receivedFrames.Enqueue(frame);
        }
        private void OnTimerElapsed(object sender, ElapsedEventArgs e)
        {
            if (_receivedFrames.Count > 0)
            {
                Frame frame = _receivedFrames.Dequeue();
                byte[] raw = frame.GetRawData();



                // https://stackoverflow.com/questions/29312223/finding-the-arithmetic-mean-of-an-array-c-sharp
                int sum = 0;
                for (int i = 0; i < raw.Length; i++)
                    sum += raw[i];

                int result = sum / raw.Length; // result now has the average of those numbers.

                _reporter.Report(result);

            }

        }

        public void StartStreaming()

        {

            _timer.Enabled = true;

        }

    }

    public class FrameGrabber : IFrameCallback

    {

        private byte[] _buffer;

        public delegate void FrameUpdateHandler(Frame rawFrame);

        public event FrameUpdateHandler OnFrameUpdated;

        public void FrameReceived(IntPtr frame, int width, int height)

        {

            if (_buffer == null)

                _buffer = new byte[width * height];

            // https://stackoverflow.com/questions/5486938/c-sharp-how-to-get-byte-from-intptr

            Marshal.Copy(frame, _buffer, 0, width * height);

            Frame bufferedFrame = new Frame(_buffer);

            OnFrameUpdated(bufferedFrame);

            bufferedFrame.Dispose();

        }

    }

    public class Frame : IDisposable

    {

        private bool _disposed;

        private byte[] _rawBuffer;

        public Frame(byte[] raw)

        {

            _rawBuffer = raw;

        }

        public byte[] GetRawData()
        {
            if (_disposed)
                throw new ObjectDisposedException("underlying buffer has changed, should not be used anymore");
            return _rawBuffer;
        }
        public void Dispose()
        {
            _disposed = true;
        }
    }
}