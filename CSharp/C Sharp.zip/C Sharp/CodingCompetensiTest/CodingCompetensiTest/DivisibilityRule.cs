﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingCompetensiTest
{
    public class DivisibilityRule
    {
        public int Divisor { get; set; }
        public string Message { get; set; }

        /**
         * Constructor division rule
         *
         */
        public DivisibilityRule(int divisor, string message)
        {
            Divisor = divisor;
            Message = message;
        }
    }
}
